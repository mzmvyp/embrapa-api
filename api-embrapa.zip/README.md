# embrapa-api
API Embrapa de raspagem de dados
